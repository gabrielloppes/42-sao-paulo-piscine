#include <stdio.h>

void	ft_ft(int *nbr);

int		main()
{
	int n = 100;

	ft_ft(&n);
	printf("%d\n", n);
	return 0;	
}
