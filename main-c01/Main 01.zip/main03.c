#include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod);

int main()
{
	int a = 44;
	int b = 87;

	int div, mod;
	ft_div_mod(a, b, &div, &mod);
	printf("A divisão de a é: %d\nA divisão de b é: %d\n", div, mod);
	return 0;
}
