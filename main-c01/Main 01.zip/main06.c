#include <stdio.h>

int	ft_strlen(char *str);

int main() {
	char str[4] = "ola";

	int len = ft_strlen(str);

	printf("%d\n", len);

    return 0;
}
