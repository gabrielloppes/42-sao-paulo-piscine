#include <stdio.h>

void		ft_is_ultimate(int *********nbr);

int		main()
{
	int ponteiro = 100;
	int *ponteiro1;
	int **ponteiro2;
	int ***ponteiro3;
	int ****ponteiro4;
	int *****ponteiro5;
	int ******ponteiro6;
	int *******ponteiro7;
	int ********ponteiro8;
	int *********ponteiro9;

	ponteiro1 = &ponteiro;
	ponteiro2 = &ponteiro1;
	ponteiro3 = &ponteiro2;
	ponteiro4 = &ponteiro3;
   	ponteiro5 = &ponteiro4;
	ponteiro6 = &ponteiro5;
	ponteiro7 = &ponteiro6;
	ponteiro8 = &ponteiro7;
	ponteiro9 = &ponteiro8;

	ft_is_ultimate(ponteiro9);
	printf("%d\n\n", ponteiro);
	return 0;
}
