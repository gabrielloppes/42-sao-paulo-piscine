#include <unistd.h>

void	ft_putstr(char *str);

void	ft_putchar(char c);

int		main()
{
	ft_putstr("Olá Mundo\n");
	return 0;
}
