#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b);

int		main()
{
	int a = 20;
	int b = 10;


	ft_ultimate_div_mod(&a, &b);
	printf("O valor de b é: %d\nE o valor de a é: %d\n", a, b);
}	
