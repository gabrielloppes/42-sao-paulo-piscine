#include <stdio.h>

void	ft_rev_int_tab(int *tab, int size);

int   main()
{
  int index1;
  int vetor1[7] = {1, 9, 3, 4, 5, 8, 10};
  int tamanho;
  tamanho = 7;
  ft_rev_int_tab(vetor1, tamanho);
  index1 = 0;
  while(index1 < tamanho)
  {
    printf("%i\n", vetor1[index1]);
    index1++;
  }

}
