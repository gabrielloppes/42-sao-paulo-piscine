#include <stdio.h>

void	ft_swap(int *a, int *b);

int		main()
{
	int a = 100;
	int b = 200;
	ft_swap(&a, &b);
	printf("O valor de a agora é: %d\n e o valor de b agora é: %d\n", a,  b);
	return 0;
}
